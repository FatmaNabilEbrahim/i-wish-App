/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.sql.Connection;

/**
 *
 * @author ibrahim
 */
public class ConnToSer {
    
    public Connection connection;
    PrintStream ps;
    DataInputStream dis;
    
    public DataInputStream getConnectionDis() throws IOException{
    Socket socket=new Socket("127.0.0.1", 5005);
    dis = new DataInputStream(socket.getInputStream());
    return dis;
    }
    
    public PrintStream getConnectionPS() throws IOException{
    Socket socket=new Socket("127.0.0.1", 5005);
    ps = new PrintStream(socket.getOutputStream());
    return ps;
    }
}
